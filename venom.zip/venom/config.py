# Don't use quotes( " and ' )
#SCRIPT BY VENOMxCRAZY
  
#Enter Your Bot Token here get it from @botfarher
BOT_TOKEN=("6847172025:AAE6BWLf2Zv83HPmtc7HC2TCsETzq3t1zuA")

  #Enter Your telegram username here without @
OWNER_USERNAME=("@Yamraj_king_yam")

  #Enter your admin id here Get it from @missRose_bot by typing /info
ADMIN_IDS=("6473868329")







  
